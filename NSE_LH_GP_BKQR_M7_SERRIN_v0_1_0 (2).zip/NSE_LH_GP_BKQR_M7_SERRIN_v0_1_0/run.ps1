#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$PackageRoot = $PSScriptRoot
$script:NativeChild = $null
$RunLock = $null
$RunLog = $null
$RunExit = 1

function Get-ProofCode([string]$Text) {
    $Buffer = New-Object System.Text.StringBuilder
    $Depth = 0; $Quoted = $false; $Index = 0
    while ($Index -lt $Text.Length) {
        $Char = $Text[$Index]; $Pair = ''
        if ($Index + 1 -lt $Text.Length) { $Pair = $Text.Substring($Index, 2) }
        if ($Depth -gt 0) {
            if ($Pair -eq '(*') { $Depth++; $Index += 2; continue }
            if ($Pair -eq '*)') { $Depth--; $Index += 2; continue }
            if ($Char -eq "`n") { [void]$Buffer.Append("`n") } else { [void]$Buffer.Append(' ') }
            $Index++; continue
        }
        if ($Quoted) {
            if ($Pair -eq '""') { $Index += 2; continue }
            if ($Char -eq '"') { $Quoted = $false }
            [void]$Buffer.Append(' '); $Index++; continue
        }
        if ($Pair -eq '(*') { $Depth = 1; [void]$Buffer.Append(' '); $Index += 2; continue }
        if ($Char -eq '"') { $Quoted = $true; [void]$Buffer.Append(' '); $Index++; continue }
        [void]$Buffer.Append($Char); $Index++
    }
    if ($Depth -ne 0 -or $Quoted) { throw 'Unterminated source comment or string.' }
    return $Buffer.ToString()
}

function Invoke-Native([string]$Executable, [string[]]$Arguments, [string]$Label) {
    $Out = Join-Path $RunLog ($Label + '.stdout.log')
    $Err = Join-Path $RunLog ($Label + '.stderr.log')
    Write-Host ($Label + '=START')
    $script:NativeChild = Start-Process -FilePath $Executable -ArgumentList $Arguments `
        -WorkingDirectory $PackageRoot -NoNewWindow -PassThru `
        -RedirectStandardOutput $Out -RedirectStandardError $Err
    $Handle = $script:NativeChild.Handle
    while (-not $script:NativeChild.WaitForExit(30000)) { Write-Host ($Label + '=RUNNING') }
    $script:NativeChild.WaitForExit(); $script:NativeChild.Refresh()
    $Code = $script:NativeChild.ExitCode
    $script:NativeChild.Dispose(); $script:NativeChild = $null
    if ($null -eq $Code -or $Code -ne 0) {
        foreach ($Path in @($Out, $Err)) {
            if (Test-Path -LiteralPath $Path) { Get-Content -LiteralPath $Path -Tail 60 | ForEach-Object { Write-Host $_ } }
        }
        throw ($Label + ' failed; native exit code=' + $Code)
    }
    Write-Host ($Label + '=PASS')
}

try {
    $RunLock = [IO.File]::Open((Join-Path $PackageRoot '.run.lock'),
        [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    $RunLog = Join-Path $PackageRoot ('logs\' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff') + '_' + $PID)
    [void](New-Item -ItemType Directory -Path $RunLog -Force)
    'RUNNING' | Set-Content -LiteralPath (Join-Path $PackageRoot 'LAST_RUN.txt') -Encoding ASCII
    $Sources = @(Get-Content -LiteralPath (Join-Path $PackageRoot 'build_order.txt') |
        ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') })
    if ($Sources.Count -eq 0) { throw 'Empty build_order.txt.' }
    $Manifest = Get-Content -LiteralPath (Join-Path $PackageRoot 'SOURCE_SHA256.json') -Raw | ConvertFrom-Json
    if (@($Manifest.PSObject.Properties).Count -ne $Sources.Count -or
        @(Get-ChildItem -LiteralPath $PackageRoot -Filter '*.v' -File).Count -ne $Sources.Count) {
        throw 'Source list, manifest and root .v files must agree.'
    }
    $CompileImports = Get-Content -LiteralPath (Join-Path $PackageRoot 'COMPILE_IMPORTS.json') -Raw | ConvertFrom-Json
    foreach ($Entry in $CompileImports.PSObject.Properties) {
        if ($Entry.Name -notin $Sources) { throw ('Unknown configured import source: ' + $Entry.Name) }
        foreach ($ImportName in @($Entry.Value)) {
            if ($ImportName -notmatch '^Stdlib\.[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)*$') {
                throw ('Only standard-library compiler imports are allowed: ' + $ImportName)
            }
        }
    }
    $Seen = @{}
    $QualifiedName = '[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)*'
    $ImportPattern = '(?:\bFrom\s+(' + $QualifiedName + ')\s+)?\bRequire\s+(?:(?:Import|Export)\s+)?(' + $QualifiedName + '(?:\s+' + $QualifiedName + ')*)\s*\.'
    foreach ($Name in $Sources) {
        if ($Name -notmatch '^[A-Za-z][A-Za-z0-9_]*\.v$' -or $Seen.ContainsKey($Name)) { throw ('Invalid build entry: ' + $Name) }
        $Path = Join-Path $PackageRoot $Name
        $Entry = $Manifest.PSObject.Properties[$Name]
        if ($null -eq $Entry -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw ('Missing source/hash: ' + $Name) }
        $Hash = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($Hash -ne [string]$Entry.Value) { throw ('Source hash mismatch: ' + $Name) }
        $Code = Get-ProofCode (Get-Content -LiteralPath $Path -Raw -Encoding UTF8)
        if ($Code -match '\b(?:Admitted|admit|Axiom|Axioms|Parameter|Parameters|Conjecture|Conjectures|Abort|Give\s+Up|exact_no_check|type_cast_no_check|vm_cast_no_check|native_cast_no_check|bypass_check)\b' -or
            $Code -match '\bUnset\s+(?:Guard|Positivity|Universe)\s+Checking\b' -or
            $Code -match '\b(?:Load|Declare\s+ML\s+Module|Add\s+(?:Rec\s+)?LoadPath)\b') {
            throw ('Forbidden project assumption or unchecked operation: ' + $Name)
        }
        foreach ($Import in [regex]::Matches($Code, $ImportPattern)) {
            $Prefix = $Import.Groups[1].Value
            if ($Prefix -eq 'Stdlib' -or $Prefix.StartsWith('Stdlib.')) { continue }
            if ($Prefix) { throw ('Unsupported import prefix in ' + $Name + ': ' + $Prefix) }
            foreach ($Dependency in ($Import.Groups[2].Value -split '\s+')) {
                if ($Dependency.StartsWith('Stdlib.')) { continue }
                if (-not $Seen.ContainsKey($Dependency + '.v')) { throw ('Missing/out-of-order local import: ' + $Dependency + ' in ' + $Name) }
            }
        }
        $Seen[$Name] = $true
    }
    Write-Host 'SOURCE_HASHES=PASS LOCAL_IMPORT_CLOSURE=PASS PROOF_ESCAPE_SCAN=PASS'
    $Candidates = @()
    foreach ($Value in @($env:ROCQ_EXE, $env:ROCQ)) { if ($Value) { $Candidates += $Value.Trim('"') } }
    foreach ($Value in @($env:ROCQ_BIN, $env:ROCQBIN)) {
        if ($Value) { foreach ($Program in @('rocq.exe','rocqc.exe')) { $Candidates += Join-Path ($Value.Trim('"')) $Program } }
    }
    foreach ($Program in @('rocq.exe','rocqc.exe')) {
        $Found = Get-Command $Program -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($Found) { $Candidates += $Found.Source }
    }
    foreach ($Directory in @(Get-ChildItem -Path 'C:\Rocq-Platform*' -Directory -ErrorAction SilentlyContinue)) {
        foreach ($Program in @('rocq.exe','rocqc.exe')) { $Candidates += Join-Path $Directory.FullName ('bin\' + $Program) }
    }
    if ($env:ProgramFiles) { $Candidates += Join-Path $env:ProgramFiles 'Rocq Platform\9.1\bin\rocq.exe' }
    $Compiler = $null
    foreach ($Candidate in $Candidates) {
        if (Test-Path -LiteralPath $Candidate -PathType Leaf) { $Compiler = (Resolve-Path -LiteralPath $Candidate).Path; break }
    }
    if (-not $Compiler) { throw 'Native Rocq 9.1 not found. Set ROCQ_EXE to the full path of rocq.exe.' }
    $CompilerName = [IO.Path]::GetFileName($Compiler).ToLowerInvariant()
    if ($CompilerName -notin @('rocq.exe','rocqc.exe')) { throw 'ROCQ_EXE must select rocq.exe or rocqc.exe.' }
    $CompilerDirectory = Split-Path -Parent $Compiler
    $Checker = Join-Path $CompilerDirectory 'rocqchk.exe'; $CheckPrefix = @()
    if (-not (Test-Path -LiteralPath $Checker -PathType Leaf)) {
        $Checker = Join-Path $CompilerDirectory 'rocq.exe'; $CheckPrefix = @('check')
        if (-not (Test-Path -LiteralPath $Checker -PathType Leaf)) { throw 'Matching-directory Rocq checker not found.' }
    }
    Invoke-Native $Compiler @('--version') 'TOOLCHAIN'
    $Version = (Get-Content -LiteralPath (Join-Path $RunLog 'TOOLCHAIN.stdout.log') -Raw).Trim()
    Write-Host $Version
    if ($Version -notmatch '(?<![0-9])9\.1(?:\.|\s|$)') { throw 'This package requires Rocq 9.1.x.' }
    Write-Host ('COMPILER=' + $Compiler); Write-Host ('CHECKER=' + $Checker)
    foreach ($Name in $Sources) {
        $Stem = [IO.Path]::GetFileNameWithoutExtension($Name)
        foreach ($Suffix in @('.vo','.vos','.vok','.vio','.glob')) {
            $OldObject = Join-Path $PackageRoot ($Stem + $Suffix)
            if (Test-Path -LiteralPath $OldObject) { Remove-Item -LiteralPath $OldObject -Force }
        }
        $Arguments = @('-q')
        $ImportEntry = $CompileImports.PSObject.Properties[$Name]
        if ($null -ne $ImportEntry) {
            foreach ($ImportName in @($ImportEntry.Value)) { $Arguments += @('-ri', [string]$ImportName) }
        }
        $Arguments += @($Name)
        if ($CompilerName -eq 'rocq.exe') { $Arguments = @('compile') + $Arguments }
        Invoke-Native $Compiler $Arguments $Stem
        $Object = Join-Path $PackageRoot ($Stem + '.vo')
        if (-not (Test-Path -LiteralPath $Object) -or (Get-Item -LiteralPath $Object).Length -eq 0) { throw ('Missing compiled object: ' + $Stem) }
        foreach ($Stream in @('stdout','stderr')) {
            Get-Content -LiteralPath (Join-Path $RunLog ($Stem + '.' + $Stream + '.log')) | ForEach-Object { Write-Host $_ }
        }
    }
    $Modules = @($Sources | ForEach-Object { [IO.Path]::GetFileNameWithoutExtension($_) })
    Write-Host 'CHECK_SCOPE=ALL_CUSTOM_MODULES_AND_FULL_RECURSIVE_DEPENDENCIES'
    Invoke-Native $Checker (@($CheckPrefix) + @('-silent','-o') + $Modules) 'ROCQCHK'
    foreach ($Stream in @('stdout','stderr')) {
        Get-Content -LiteralPath (Join-Path $RunLog ('ROCQCHK.' + $Stream + '.log')) | ForEach-Object { Write-Host $_ }
    }
    Write-Host 'FOUNDATIONS=STDLIB_REAL_CLASSICAL_AS_PRINTED PROJECT_AXIOM_DECLARATIONS=NONE'
    $Summary = @(Get-Content -LiteralPath (Join-Path $PackageRoot 'SUMMARY.txt'))
    foreach ($Key in @('CLAIM_BOUNDARY','BASELINE_PRESERVATION','SAME_PATH_CHAIN','M7_MASS','PREFIX_PAYMENT','PAYMENT_THRESHOLD','COUNTABLE_READOUTS','DISSIPATION_CUTOFF_LIMIT','SERRIN46_BOUND','CONTINUATION','PHYSICAL_REALIZATION','GLOBAL_REGULARITY')) {
        $Status = @($Summary | Where-Object { $_ -cmatch ('^' + $Key + '=[A-Z0-9_]+$') })
        if ($Status.Count -ne 1) { throw ('SUMMARY.txt must contain exactly one ' + $Key + '=VALUE line.') }
        Write-Host $Status[0]
    }
    Write-Host 'RUN=PASS'
    ('PASS ' + $RunLog) | Set-Content -LiteralPath (Join-Path $PackageRoot 'LAST_RUN.txt') -Encoding UTF8
    $RunExit = 0
} catch {
    Write-Host ('RUN_ERROR=' + $_.Exception.Message)
    Write-Host 'RUN=FAIL ROCQCHK=NOT_CONFIRMED_BY_THIS_RUN'
    if ($RunLog) { ('FAIL ' + $_.Exception.Message) | Set-Content -LiteralPath (Join-Path $PackageRoot 'LAST_RUN.txt') -Encoding UTF8 }
} finally {
    if ($null -ne $script:NativeChild) {
        try { if (-not $script:NativeChild.HasExited) { $script:NativeChild.Kill(); $script:NativeChild.WaitForExit() } } catch { }
        $script:NativeChild.Dispose()
    }
    if ($null -ne $RunLock) { $RunLock.Dispose() }
}
exit $RunExit
