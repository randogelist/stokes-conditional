FEF_NSE_WHOLESPACE_A_A_TIER_CLOSURE_LEAN_v0_24_0

TARGET
======
A-tier closure of Fefferman whole-space alternative A in the concrete Real
analysis regime.

Direct endpoint:

  WholeSpaceZeroForceGlobalRegularity :=
    for every positive viscosity and every admissible whole-space initial
    datum, there exists an official global solution with zero force.

Target equivalences:

  WholeSpaceZeroForceGlobalRegularity <-> A realAnalysis
  WholeSpaceAPhysicalPort <-> A realAnalysis

No unconditional global regularity is claimed.  The purpose is to remove all
derivation-model/port indirection and leave one exact semantic PDE endpoint,
symmetric to the periodic B closure.

Run:
cd /d "%USERPROFILE%\Downloads" && tar.exe -xf "FEF_NSE_WHOLESPACE_A_A_TIER_CLOSURE_LEAN_v0_24_0.zip" && call "FEF_NSE_WHOLESPACE_A_A_TIER_CLOSURE_LEAN_v0_24_0\run.cmd"
