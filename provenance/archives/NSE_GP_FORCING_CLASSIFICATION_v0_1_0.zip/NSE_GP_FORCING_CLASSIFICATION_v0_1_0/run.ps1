param([string]$RocqBin = $env:ROCQBIN)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
Set-Location -LiteralPath $root
$logDir = Join-Path $root 'logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$runLog = Join-Path $logDir 'run.log'
Set-Content -LiteralPath $runLog -Value '' -Encoding UTF8
function Say([string]$text) {
  Write-Host $text
  Add-Content -LiteralPath $runLog -Value $text -Encoding UTF8
}
function Run-Native([string]$exe, [string[]]$argv, [string]$tag) {
  $stdout = Join-Path $logDir ($tag + '.stdout.log')
  $stderr = Join-Path $logDir ($tag + '.stderr.log')
  $p = Start-Process -FilePath $exe -ArgumentList $argv -WorkingDirectory $root `
       -NoNewWindow -Wait -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
  foreach ($path in @($stdout,$stderr)) {
    if ((Test-Path -LiteralPath $path) -and (Get-Item -LiteralPath $path).Length -gt 0) {
      $text = Get-Content -LiteralPath $path -Raw
      Write-Host $text
      Add-Content -LiteralPath $runLog -Value $text -Encoding UTF8
    }
  }
  if ($p.ExitCode -ne 0) { throw ('NATIVE_FAILURE=' + $tag + ' EXIT=' + $p.ExitCode) }
}
function Strip-CoqComments([string]$text) {
  $b = New-Object System.Text.StringBuilder
  $depth = 0; $inString = $false; $i = 0
  while ($i -lt $text.Length) {
    $ch = $text[$i]
    $pair = if ($i + 1 -lt $text.Length) { $text.Substring($i,2) } else { '' }
    if ($depth -gt 0) {
      if ($pair -eq '(*') { $depth++; $i += 2; continue }
      if ($pair -eq '*)') { $depth--; $i += 2; continue }
      if ($ch -eq "`n") { [void]$b.Append("`n") }
      $i++; continue
    }
    if ($inString) {
      if ($pair -eq '""') { $i += 2; continue }
      if ($ch -eq '"') { $inString = $false }
      [void]$b.Append(' '); $i++; continue
    }
    if ($pair -eq '(*') { $depth = 1; [void]$b.Append(' '); $i += 2; continue }
    if ($ch -eq '"') { $inString = $true; [void]$b.Append(' '); $i++; continue }
    [void]$b.Append($ch); $i++
  }
  if ($depth -ne 0 -or $inString) { throw 'UNCLOSED_COMMENT_OR_STRING' }
  return $b.ToString()
}
try {
  Say 'PACKAGE=NSE_GP_FORCING_CLASSIFICATION_v0_1_0'
  $sources = @(Get-Content -LiteralPath (Join-Path $root 'sources.txt') | Where-Object { $_.Trim() })
  foreach ($source in $sources) {
    $path = Join-Path $root $source
    if (-not (Test-Path -LiteralPath $path)) { throw ('MISSING_SOURCE=' + $source) }
    $code = Strip-CoqComments (Get-Content -LiteralPath $path -Raw)
    $bad = '(?im)\b(Admitted|admit|give_up|Abort)\s*\.|^\s*(Axiom|Axioms|Parameter|Parameters|Conjecture)\b|\b(abstract_no_check|vm_cast_no_check|native_cast_no_check|exact_no_check)\b'
    if ($code -match $bad) { throw ('FORBIDDEN_PROOF_ESCAPE=' + $source + ' TOKEN=' + $Matches[0]) }
  }
  Say 'PROOF_ESCAPE_SCAN=PASS'
  $candidates = @()
  if ($RocqBin) { $candidates += (Join-Path $RocqBin 'rocq.exe') }
  $cmd = Get-Command rocq.exe -ErrorAction SilentlyContinue
  if ($cmd) { $candidates += $cmd.Source }
  $candidates += 'C:\Rocq-Platform~9.1~2026.01\bin\rocq.exe'
  $candidates += @(Get-ChildItem -Path 'C:\Rocq-Platform~9.1~*\bin\rocq.exe' -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
  if ($env:ProgramFiles) { $candidates += (Join-Path $env:ProgramFiles 'Rocq Platform\9.1\bin\rocq.exe') }
  $compiler = @($candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1)
  if ($compiler.Count -eq 0) { throw 'ROCQ_NOT_FOUND: set ROCQBIN to your Rocq 9.1 bin directory.' }
  $compiler = $compiler[0]
  $checker = Join-Path (Split-Path -Parent $compiler) 'rocqchk.exe'
  if (-not (Test-Path -LiteralPath $checker)) { throw ('KERNEL_CHECKER_NOT_FOUND=' + $checker) }
  Say ('ROCQ=' + $compiler)
  Run-Native $compiler @('--version') 'version'
  $version = (Get-Content -LiteralPath (Join-Path $logDir 'version.stdout.log') -Raw) +
             (Get-Content -LiteralPath (Join-Path $logDir 'version.stderr.log') -Raw)
  if ($version -notmatch '\b9\.1\b') { throw 'EXPECTED_ROCQ_9_1' }
  foreach ($source in $sources) {
    $stem = [System.IO.Path]::GetFileNameWithoutExtension($source)
    foreach ($suffix in @('.vo','.vos','.vok','.glob')) {
      $obj = Join-Path $root ($stem+$suffix)
      if (Test-Path -LiteralPath $obj) { Remove-Item -LiteralPath $obj -Force }
    }
    $aux = Join-Path $root ('.'+$stem+'.aux')
    if (Test-Path -LiteralPath $aux) { Remove-Item -LiteralPath $aux -Force }
  }
  $k=0
  foreach ($source in $sources) {
    $k++
    Say ('COMPILE_START=' + $k + '/' + $sources.Count + ' FILE=' + $source)
    Run-Native $compiler @('compile',$source) ('compile_'+$k.ToString('00'))
    Say ('COMPILE=PASS FILE=' + $source)
  }
  Run-Native $checker @('awpi_nse_gp_forcing_classification_v0_1_0') 'kernel_check'
  Say 'ROCQCHK=PASS'
  Say 'ZERO_FORCE_IS_GP_NULL=KERNEL_TARGET'
  Say 'ZERO_FORCE_IS_ZERO_RELATIVE_GP_BUDGET=KERNEL_TARGET'
  Say 'FINITE_GP_TIME_WORK_IS_RELATIVE_THETA_ZERO=KERNEL_TARGET'
  Say 'INTERNAL_PLUS_EXTERNAL_RELATIVE_BUDGETS_ADD=KERNEL_TARGET'
  Say 'SUBUNIT_TOTAL_MARGIN=KERNEL_TARGET'
  Say 'SAFE_FORCING_GIVES_CRITICAL_BOUNDS=KERNEL_TARGET'
  Say 'ZERO_FORCE_RECOVERS_UNFORCED_CLOSURE_CONSTANTS=KERNEL_TARGET'
  Say 'FORCING_CLASSIFICATION=TRAJECTORY_RELATIVE_GP_WORK_NOT_NORM_ONLY'
  Say 'TIME_INTEGRABILITY_ALONE=NOT_CLAIMED_SUFFICIENT'
  Say 'SMOOTH_FORCING_ALONE=NOT_CLAIMED_SUFFICIENT'
  Say 'FORCED_LEDGER_REALIZATION=OPEN_ANALYTIC_FRONTIER'
  Say 'INTERNAL_SIGNED_PRODUCTION_BUDGET=OPEN_M7_PAYMENT_FRONTIER'
  Say 'GLOBAL_FORCED_NSE_REGULARITY=NOT_CLAIMED_BY_THIS_PACKAGE'
  Say 'RUN=PASS'
  exit 0
} catch {
  Say ('BUILD=FAIL ' + $_.Exception.Message)
  Say ('LOG=' + $runLog)
  exit 1
}
