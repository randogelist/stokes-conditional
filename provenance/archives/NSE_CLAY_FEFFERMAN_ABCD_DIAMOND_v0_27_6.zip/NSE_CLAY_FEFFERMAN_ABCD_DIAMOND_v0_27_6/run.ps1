$ErrorActionPreference = 'Stop'
Write-Host 'RUNNER_PACKAGE=NSE_CLAY_FEFFERMAN_ABCD_DIAMOND_V0_27_6'
Write-Host 'RUNNER_EXPECTS=FRAMEWORK_PLUS_A_PLUS_B_PLUS_C_PLUS_D_ONLY'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root
[System.Environment]::CurrentDirectory = $root

function Find-RocqBin {
  if ($env:ROCQBIN) {
    $r = Join-Path $env:ROCQBIN 'rocq.exe'
    $c = Join-Path $env:ROCQBIN 'rocqchk.exe'
    if ((Test-Path -LiteralPath $r) -and (Test-Path -LiteralPath $c)) { return $env:ROCQBIN }
  }
  $preferred = 'C:\Rocq-Platform~9.1~2026.01\bin'
  if ((Test-Path -LiteralPath (Join-Path $preferred 'rocq.exe')) -and
      (Test-Path -LiteralPath (Join-Path $preferred 'rocqchk.exe'))) { return $preferred }
  $cmd = Get-Command rocq.exe -ErrorAction SilentlyContinue
  if ($cmd) {
    $b = Split-Path -Parent $cmd.Source
    if (Test-Path -LiteralPath (Join-Path $b 'rocqchk.exe')) { return $b }
  }
  throw 'rocq.exe/rocqchk.exe not found. Set ROCQBIN to Rocq 9.1 bin.'
}

$bin = Find-RocqBin
$rocq = Join-Path $bin 'rocq.exe'
$chk = Join-Path $bin 'rocqchk.exe'
$platformRoot = Split-Path -Parent $bin
$dllDirs = New-Object System.Collections.Generic.List[string]
$dllDirs.Add($bin)
foreach($dllName in @('libgmp-10.dll','libgcc_s_seh-1.dll','libwinpthread-1.dll','libstdc++-6.dll')) {
  $hit = Get-ChildItem -LiteralPath $platformRoot -Filter $dllName -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($hit) {
    $d = $hit.Directory.FullName
    if (-not $dllDirs.Contains($d)) { $dllDirs.Add($d) }
    Write-Host "DLL_$dllName=$($hit.FullName)"
  }
}
$env:PATH = ((@($dllDirs) + @($env:PATH -split ';' | Where-Object { $_ })) | Select-Object -Unique) -join ';'
$env:ROCQBIN = $bin

$build = Join-Path $root '.build'
if (Test-Path -LiteralPath $build) { Remove-Item -LiteralPath $build -Recurse -Force }
New-Item -ItemType Directory -Path $build | Out-Null

# Stage dependency sources.
Get-ChildItem -LiteralPath (Join-Path $root '00_FRAMEWORK\vendor') -Filter '*.v' -File | ForEach-Object {
  Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $build $_.Name)
}
# Stage exactly one source module from each of the five subpackages.
$srcs = @(
  '00_FRAMEWORK\NSE_CLAY_FEFFERMAN_FRAMEWORK.v',
  '01_A_R3_UNFORCED\NSE_CLAY_FEFFERMAN_A_R3_UNFORCED.v',
  '02_B_T3_UNFORCED\NSE_CLAY_FEFFERMAN_B_T3_UNFORCED.v',
  '03_C_R3_FORCED_BREAKDOWN\NSE_CLAY_FEFFERMAN_C_R3_FORCED_BREAKDOWN.v',
  '04_D_T3_FORCED_BREAKDOWN\NSE_CLAY_FEFFERMAN_D_T3_FORCED_BREAKDOWN.v'
)
foreach($rel in $srcs) {
  $p = Join-Path $root $rel
  Copy-Item -LiteralPath $p -Destination (Join-Path $build ([IO.Path]::GetFileName($p)))
}
Copy-Item -LiteralPath (Join-Path $root 'build_order.txt') -Destination (Join-Path $build 'build_order.txt')

Set-Location -LiteralPath $build
[System.Environment]::CurrentDirectory = $build
Write-Host "ROOT=$root"
Write-Host "BUILD=$build"
Write-Host "ROCQ=$rocq"
& $rocq --version
if ($LASTEXITCODE -ne 0) { throw "rocq --version failed: $LASTEXITCODE" }

$files = @(Get-Content -LiteralPath (Join-Path $build 'build_order.txt') | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') })
$i=0
foreach($f in $files) {
  $i++
  $full = Join-Path $build $f
  if (-not (Test-Path -LiteralPath $full)) { throw "COMPILE_FILE=$f MISSING" }
  Write-Host "[$i/$($files.Count)] COMPILE $f"
  & $rocq compile -q $full
  if ($LASTEXITCODE -ne 0) { throw "COMPILE_FILE=$f FAIL exit=$LASTEXITCODE" }
  Write-Host "COMPILE_FILE=$f PASS"
}
Write-Host 'COMPILE=PASS'

Write-Host '[ROCQCHK]'
$mods = @($files | ForEach-Object { [IO.Path]::GetFileNameWithoutExtension($_) })
& $chk -silent @mods
if ($LASTEXITCODE -ne 0) { throw "ROCQCHK=FAIL exit=$LASTEXITCODE" }
Write-Host 'ROCQCHK=PASS'

$bad = Select-String -Path (Join-Path $build '*.v') -Pattern '^\s*(?:(?:Local|Global)\s+)?(?:Admitted|admit|Axiom|Parameter|Abort)\b' -AllMatches -ErrorAction SilentlyContinue
if ($bad) {
  $bad | ForEach-Object { Write-Host $_ }
  throw 'PROOF_ESCAPE_SCAN=FAIL'
}
Write-Host 'PROOF_ESCAPE_SCAN=PASS'

Write-Host 'STATUS=NSE_CLAY_FEFFERMAN_ABCD_DIAMOND_V0_27_6'
Write-Host 'SUBPACKAGE_0_FRAMEWORK=TWO_SHARED_DOMAIN_DIAMONDS_PLUS_FORCE_CLASSIFICATION'
Write-Host 'SUBPACKAGE_A=R3_ZERO_FORCE_COROLLARY_OF_CONCRETE_STORAGE_TERMINAL_DIAMOND'
Write-Host 'SUBPACKAGE_B=T3_ZERO_FORCE_COROLLARY_OF_SHARED_T3_DOMAIN_DIAMOND'
Write-Host 'SUBPACKAGE_C=R3_FORCE_CLASSIFICATION_FROM_CONCRETE_STORAGE_TERMINAL_DIAMOND'
Write-Host 'SUBPACKAGE_D=T3_FORCE_CLASSIFICATION_FROM_SHARED_T3_DOMAIN_DIAMOND'
Write-Host 'A_AND_C_SHARE_R3_CONCRETE_STORAGE_TERMINAL_DIAMOND=KERNEL_TARGET'
Write-Host 'B_AND_D_SHARE_T3_DOMAIN_DIAMOND=KERNEL_TARGET'
Write-Host 'FOUR_STATEMENTS_REDUCED_TO_TWO_DOMAIN_DIAMONDS_PLUS_CLAY_FORCE_EMBEDDINGS=KERNEL_TARGET'
Write-Host 'UNCONDITIONAL_CLAY_SOLUTION=NOT_CLAIMED'
Write-Host 'R3_A_C_SHARED_CONCRETE_STORAGE_TERMINAL_DIAMOND=KERNEL_TARGET'
Write-Host 'R3_STORAGE_TERMINAL_WITNESS_TO_UNIFORM_CRITICAL_BOUND=KERNEL_TARGET'
Write-Host 'R3_STORAGE_TO_CRITICAL_READOUT=ELIMINATED_AS_SEPARATE_INTERFACE'
Write-Host 'R3_STORAGE_WITNESS_REALIZATION=OPEN_RESEARCH_INTERFACE'
Write-Host 'R3_CRITICAL_TO_SMOOTH_EXIT=OPEN_CLASSICAL_INTERFACE'
Write-Host 'RUN=PASS'
