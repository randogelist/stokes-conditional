FEF_NSE_WHOLESPACE_C_A_TIER_CLOSURE_LEAN_v0_23_0

TARGET
======
A-tier closure of Fefferman whole-space alternative C in the concrete Real
analysis regime.

Direct endpoint:
  WholeSpaceForcedBreakdown

meaning: for every positive viscosity there exist an admissible whole-space
initial datum and admissible whole-space force for which no official global
solution exists.

Target equivalences:
  WholeSpaceForcedBreakdown <-> C realAnalysis
  WholeSpaceCPhysicalPort <-> C realAnalysis

Also includes the stronger zero-initial source route and a Type-valued
WholeSpaceSourceSemanticPort carrying an actual viscosity-indexed force family.

No unconditional breakdown is claimed.  The hard remaining field is the
whole-space noGlobal witness family.

Run:
cd /d "%USERPROFILE%\Downloads" && tar.exe -xf "FEF_NSE_WHOLESPACE_C_A_TIER_CLOSURE_LEAN_v0_23_0.zip" && call "FEF_NSE_WHOLESPACE_C_A_TIER_CLOSURE_LEAN_v0_23_0\run.cmd"
