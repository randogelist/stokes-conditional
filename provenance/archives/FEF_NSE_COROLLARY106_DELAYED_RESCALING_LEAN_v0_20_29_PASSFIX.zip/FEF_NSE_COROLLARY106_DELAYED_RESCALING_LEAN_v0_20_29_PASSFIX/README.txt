FEF_NSE_COROLLARY106_DELAYED_RESCALING_LEAN_v0_20_29_PASSFIX

PASSFIX
-------
v0.20.28 already elaborated and axiom-audited the full delayed-rescaling
theorem cone with no `sorryAx`.

The sole compiler failure was:

  dependsOnNoncomputable:
  delayedRescaleForce depends on Real.decidableLT

because its source-faithful definition branches on:

  if t < t0 then 0 else ...

For Real, this decision procedure is noncomputable.

FIX:
  def delayedRescaleForce
becomes
  noncomputable def delayedRescaleForce

No definition body, theorem statement, proof, hypothesis, or runner architecture
changes.

Run:
cd /d "%USERPROFILE%\Downloads" && tar.exe -xf "FEF_NSE_COROLLARY106_DELAYED_RESCALING_LEAN_v0_20_29_PASSFIX.zip" && call "FEF_NSE_COROLLARY106_DELAYED_RESCALING_LEAN_v0_20_29_PASSFIX\run.cmd"
