$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $root 'NSEForcingRegularityClasses.lean'
$log = Join-Path $root 'lean-build.log'
Write-Host 'PACKAGE=NSE_FORCING_REGULARITY_CLASSES_LEAN_v0_1_4'

$bad = Select-String -LiteralPath $src -Pattern '\bsorry\b|\badmit\b|\baxiom\b' -CaseSensitive:$false
if ($bad) {
  Write-Host 'PROOF_ESCAPE_SCAN=FAIL'
  $bad | ForEach-Object { Write-Host $_.Line }
  exit 1
}
Write-Host 'PROOF_ESCAPE_SCAN=PASS'

$env:LEAN_NUM_THREADS = '16'
$candidates = @(
  (Join-Path $env:USERPROFILE 'lean-native\awpi_phi_rh_lean_sieved_v0_1_1'),
  (Join-Path $env:USERPROFILE 'lean-native')
)
$base = $null
foreach ($c in $candidates) {
  if (((Test-Path (Join-Path $c 'lakefile.toml')) -or (Test-Path (Join-Path $c 'lakefile.lean'))) -and (Test-Path (Join-Path $c '.lake\packages\mathlib'))) {
    $base = $c
    break
  }
}
if (-not $base) {
  $base = Get-ChildItem -LiteralPath (Join-Path $env:USERPROFILE 'lean-native') -Directory -ErrorAction SilentlyContinue |
    Where-Object { (Test-Path (Join-Path $_.FullName '.lake\packages\mathlib')) -and ((Test-Path (Join-Path $_.FullName 'lakefile.toml')) -or (Test-Path (Join-Path $_.FullName 'lakefile.lean'))) } |
    Sort-Object LastWriteTime -Descending |
    Select-Object -ExpandProperty FullName -First 1
}
if (-not $base) { throw 'Pinned/cached mathlib workspace not found under ~/lean-native' }

$lake = $null
$elanLake = Join-Path $env:USERPROFILE '.elan\bin\lake.exe'
if (Test-Path $elanLake) { $lake = $elanLake }
if (-not $lake) {
  $cmd = Get-Command lake.exe -ErrorAction SilentlyContinue
  if ($cmd) { $lake = $cmd.Source }
}
if (-not $lake) { throw 'lake.exe not found' }

Write-Host ('MATHLIB_BASE=' + $base)
Write-Host ('LAKE=' + $lake)
Write-Host 'COMPILE_START'
Push-Location $base
try {
  $out = & $lake env lean $src 2>&1
  $code = $LASTEXITCODE
  $out | Tee-Object -FilePath $log | ForEach-Object { Write-Host $_ }
  if ($code -ne 0) {
    Write-Host ('LEAN_EXIT=' + $code)
    Write-Host ('LOG=' + $log)
    exit $code
  }
} finally {
  Pop-Location
}
Write-Host 'COMPILE=PASS'
Write-Host 'NO_SORRY_OR_ADMIT=PASS'
Write-Host 'CRITICAL_FORCING_SCALING_LINE=LEAN_TARGET'
Write-Host 'L2_TIME_CRITICAL_SPATIAL_EXPONENT_MINUS_HALF=LEAN_TARGET'
Write-Host 'L1_TIME_CRITICAL_SPATIAL_EXPONENT_PLUS_HALF=LEAN_TARGET'
Write-Host 'REGULAR_FORCE_EXPONENT_IMPLIES_LH_ADMISSIBLE_EXPONENT=LEAN_TARGET'
Write-Host 'LH_EXPONENT_PARTITION_REGULAR_OR_IRREGULAR=LEAN_TARGET'
Write-Host 'REGULAR_AND_IRREGULAR_FORCE_CLASSES_DISJOINT=LEAN_TARGET'
Write-Host 'LH_POWER_TAIL_THRESHOLD_HALF=LEAN_TARGET'
Write-Host 'CRITICAL_POWER_TAIL_THRESHOLD_ONE=LEAN_TARGET'
Write-Host 'IRREGULAR_BUT_LH_POWER_TAIL_STRIP_HALF_TO_ONE=LEAN_TARGET'
Write-Host 'L2_LH_TRICHOTOMY_SMOOTH_CRITICAL_ROUGH=LEAN_TARGET'
Write-Host 'EXACT_CRITICAL_IFF_SCALING_ZERO=LEAN_TARGET'
Write-Host 'SMOOTH_IFF_SCALING_POSITIVE=LEAN_TARGET'
Write-Host 'ROUGH_LH_IFF_SCALING_NEGATIVE_WITH_LH=LEAN_TARGET'
Write-Host 'POWER_TAIL_TRICHOTOMY=LEAN_TARGET'
Write-Host 'POWER_TAIL_ALPHA_ONE_EXACT_BOUNDARY=LEAN_TARGET'
Write-Host 'ACTUAL_SOBOLEV_SPACE_REALIZATION=OPEN_ANALYTIC_FRONTIER'
Write-Host 'SOLUTION_REGULARITY_FROM_FORCE_CLASS_ALONE=NOT_CLAIMED'
Write-Host 'SOLUTION_BREAKDOWN_FROM_FORCE_CLASS_ALONE=NOT_CLAIMED'
Write-Host 'RUN=PASS'
