@echo off

setlocal EnableExtensions EnableDelayedExpansion

set "DL=%USERPROFILE%\Downloads"

set "BASEZIP=%DL%\FEF_NSE_MASTERAC_TWO_LAYER_LEAN_v0_11_0.zip"

set "WORK=%DL%\FEF_NSE_CONCRETE_PERIODIZATION_TRANSLATION_CLOSED_WORKTREE_v0_20_26"

set "RUNNER="

set "ROOT="

set "BASEOLEAN="

set "MATHLIBLEAN="

set "PACKAGES="

set "EXTRA_PATHS="

set "LEAN_EXE=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0\bin\lean.exe"

set "OUTDIR=%WORK%\concrete_build"

set "SRC=%~dp0ConcretePeriodizationTranslationClosed.lean"

echo RUNNER_ENTERED=PASS

echo PACKAGE=FEF_NSE_CONCRETE_PERIODIZATION_TRANSLATION_CLOSED_LEAN_v0_20_26_PASSFIX

echo MODE=BASE_CORE_BUILD_PLUS_SEPARATE_NATIVE_MATHLIB_LAYER

echo NETWORK=NOT_USED

echo PYTHON=NOT_USED

echo POWERSHELL=NOT_USED

echo WSL=NOT_USED

echo LAKE=NOT_USED

echo DEPENDENCY_DOWNLOAD=DISABLED

if not exist "%BASEZIP%" (

  echo BASE_ZIP_FOUND=NO

  exit /b 2

)

echo BASE_ZIP_FOUND=YES

if not exist "%LEAN_EXE%" (

  echo LEAN_EXE_FOUND=NO

  exit /b 3

)

echo LEAN_EXE=%LEAN_EXE%

if exist "%WORK%" rmdir /s /q "%WORK%"

mkdir "%WORK%"

if errorlevel 1 exit /b 4

tar.exe -xf "%BASEZIP%" -C "%WORK%"

if errorlevel 1 exit /b 5

echo BASE_EXTRACT=PASS

set "ANALYSIS_SRC="
set "CANDIDATE_ROOT="

for /f "delims=" %%A in ('dir /s /b /a:-d "%WORK%\Analysis.lean" 2^>nul') do (
  for %%P in ("%%~dpA.") do (
    if /i "%%~nxP"=="Fefferman" (
      for %%R in ("%%~dpA..") do (
        if exist "%%~fR\Master_T3_derivation.lean" (
          if exist "%%~fR\run.cmd" (
            if not defined ANALYSIS_SRC (
              set "ANALYSIS_SRC=%%~fA"
              set "CANDIDATE_ROOT=%%~fR"
            )
          )
        )
      )
    )
  )
)

if not defined ANALYSIS_SRC (
  echo NSE_ANALYSIS_SOURCE_FOUND=NO
  echo SEARCH_ROOT=%WORK%
  echo CANDIDATE_SCAN=Analysis.lean_PARENT_FefferMan_PLUS_Master_T3_derivation_PLUS_run.cmd
  exit /b 6
)

set "ROOT=%CANDIDATE_ROOT%"
set "RUNNER=%ROOT%\run.cmd"

if not exist "%RUNNER%" (
  echo NSE_ROOT_RUNNER_FOUND=NO
  echo EXPECTED_RUNNER=%RUNNER%
  exit /b 7
)
if not exist "%ROOT%\Fefferman\Analysis.lean" (
  echo NSE_ANALYSIS_AT_RESOLVED_ROOT=NO
  exit /b 8
)
if not exist "%ROOT%\Master_T3_derivation.lean" (
  echo NSE_MASTER_T3_SOURCE_FOUND=NO
  exit /b 9
)

echo NSE_ANALYSIS_SOURCE_FOUND=YES
echo NSE_ANALYSIS_SOURCE=%ANALYSIS_SRC%
echo NSE_MASTER_T3_SOURCE_FOUND=YES
echo NSE_ROOT_RUNNER_FOUND=YES
echo PROJECT_ROOT=%ROOT%
echo BASE_RUNNER=%RUNNER%
echo BASE_IDENTITY_CHECK=PASS

pushd "%ROOT%"

call "%RUNNER%"

set "RC=!ERRORLEVEL!"

popd

if not "!RC!"=="0" (

  echo BASE_PROJECT_BUILD=FAIL

  exit /b !RC!

)

echo BASE_PROJECT_BUILD=PASS

set "BASE_ANALYSIS_OLEAN="
for /f "delims=" %%O in ('dir /s /b /a:-d /o:-d "%ROOT%\build\Analysis.olean" 2^>nul') do if not defined BASE_ANALYSIS_OLEAN set "BASE_ANALYSIS_OLEAN=%%~fO"

if not defined BASE_ANALYSIS_OLEAN (
  echo BASE_OLEAN_FOUND=NO
  echo OLEAN_SEARCH_ROOT=%ROOT%\build
  exit /b 10
)

echo BASE_OLEAN_FOUND=YES
echo BASE_ANALYSIS_OLEAN=%BASE_ANALYSIS_OLEAN%

for %%D in ("%BASE_ANALYSIS_OLEAN%") do set "BASEOLEAN=%%~dpD"
for %%D in ("%BASEOLEAN%..") do set "BASEOLEAN=%%~fD"

echo BASE_OLEAN_ROOT=%BASEOLEAN%

for /f "delims=" %%M in ('dir /s /b /a:-d "%USERPROFILE%\lean-native\Mathlib.olean" 2^>nul') do if not defined MATHLIBLEAN set "MATHLIBLEAN=%%~dpM"

if not defined MATHLIBLEAN (

  for /f "delims=" %%M in ('dir /s /b /a:-d "%USERPROFILE%\lean-native\*\.lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean" 2^>nul') do if not defined MATHLIBLEAN set "MATHLIBLEAN=%%~dpM"

)

if not defined MATHLIBLEAN (

  echo NATIVE_CACHED_MATHLIB_FOUND=NO

  echo EXPECTED_UNDER=%USERPROFILE%\lean-native

  exit /b 8

)

echo NATIVE_CACHED_MATHLIB_FOUND=YES

echo MATHLIB_LEAN=%MATHLIBLEAN%

for %%D in ("%MATHLIBLEAN%\..\..\..\..\..") do set "PACKAGES=%%~fD"

echo PACKAGE_CACHE_ROOT=%PACKAGES%

set "EXTRA_PATHS="

for /d %%P in ("%PACKAGES%\*") do (

  if exist "%%~fP\.lake\build\lib\lean" (

    if defined EXTRA_PATHS (

      set "EXTRA_PATHS=!EXTRA_PATHS!;%%~fP\.lake\build\lib\lean"

    ) else (

      set "EXTRA_PATHS=%%~fP\.lake\build\lib\lean"

    )

  )

)

if not exist "%OUTDIR%" mkdir "%OUTDIR%"

set "LEAN_PATH=%BASEOLEAN%;%MATHLIBLEAN%;!EXTRA_PATHS!"

echo CONCRETE_LEAN_PATH_READY=YES

echo FOREIGN_RUNNER_SELECTION=DISABLED
echo COMPILE_START=ConcretePeriodizationTranslationClosed

"%LEAN_EXE%" "%SRC%" -o "%OUTDIR%\ConcretePeriodizationTranslationClosed.olean" > "%OUTDIR%\ConcretePeriodizationTranslationClosed.log" 2>&1

set "RC=!ERRORLEVEL!"

type "%OUTDIR%\ConcretePeriodizationTranslationClosed.log"

if not "!RC!"=="0" (
  echo CONCRETE_REAL_COMPILE=FAIL
  echo LOG=%OUTDIR%\ConcretePeriodizationTranslationClosed.log
  echo ==================== FIRST_ERRORS_BEGIN ====================
  findstr /n /c:"error:" "%OUTDIR%\ConcretePeriodizationTranslationClosed.log"
  echo ===================== FIRST_ERRORS_END =====================
  exit /b !RC!
)

echo CONCRETE_REAL_COMPILE=PASS

echo BASE_CORE_PROJECT_UNCHANGED=YES

echo MATHLIB_LAYER_SEPARATE=YES

echo SCALAR=REAL

echo SPACE=REAL_CUBED_AS_FIN3_TO_REAL

echo SPATIAL_DERIVATIVE=FDERIV_DIRECTIONAL

echo TIME_DERIVATIVE=DERIV

echo SPATIAL_SMOOTHNESS=CONTDIFF

echo HALFSPACE_SMOOTHNESS=CONTDIFFON

echo INTEGRAL_NORM_SQ=MEASURE_INTEGRAL

echo INTEGER_SHIFT=EXPLICIT_Z3_ACTION

echo RESCALED_FORCE=EXPLICIT

echo PERIODIC_FORCE=LITERAL_TSUM_OVER_Z3

echo SUPPORT_MODEL=STRICT_OPEN_CUBE

echo SUPPORT_WIDTH_CONDITION=TWO_RHO_LT_ONE

echo ACTIVE_LATTICE_TRANSLATE=AT_MOST_ONE

echo TSUM_COLLAPSE_TO_ACTIVE_TRANSLATE=KERNEL_TARGET

echo ACTIVE_SET_SUBSINGLETON=KERNEL_TARGET

echo BUFFERED_CUBE=RHO_LT_SIGMA_LT_HALF

echo ACTIVE_COPY_LOCAL_REPRESENTATION=KERNEL_TARGET

echo GAP_REGION_LOCAL_ZERO=KERNEL_TARGET

echo EVERY_POINT_LOCAL_SINGLE_OR_ZERO=KERNEL_TARGET

echo LOCAL_FINITE_PERIODIZATION_MECHANISM=EXPLICIT

echo SPACE_BOX_OPEN=KERNEL_TARGET
echo LOCAL_EQUALITY_TO_SINGLE_COPY=UPGRADED_TO_EVENTUAL_EQUALITY
echo TRANSLATED_SOURCE_CONTDIFF=KERNEL_TARGET
echo PERIODIZED_COMPONENT_CONTDIFF=KERNEL_TARGET
echo PERIODIZED_FORCE_GLOBAL_CONTDIFF=KERNEL_TARGET
echo PERIODIZED_FORCE_OFFICIAL_VECTOR_SMOOTH=KERNEL_TARGET
echo DERIVATIVE_COMMUTATION=NEXT_FRONTIER
echo EVENTUAL_SPATIAL_SINGLE_COPY=KERNEL_TARGET
echo FDERIV_LOCALITY=KERNEL_TARGET
echo LATTICE_TRANSLATION_FDERIV_IDENTITY=KERNEL_TARGET
echo FIRST_SPATIAL_DERIVATIVE_SOURCE_LOCAL=KERNEL_TARGET
echo FIRST_TIME_DERIVATIVE_LOCAL=KERNEL_TARGET
echo MIXED_JET_INDUCTION=NEXT_FRONTIER
echo REPEATED_TIME_DERIVATIVE_LOCALITY=KERNEL_TARGET
echo REPEATED_SPATIAL_DERIVATIVE_LOCALITY=KERNEL_TARGET
echo SPATIAL_JET_LOCALITY=KERNEL_TARGET
echo MIXED_JET_LOCALITY=KERNEL_TARGET
echo ZERO_FORCE_ALL_MIXED_JETS_ZERO=KERNEL_TARGET
echo PERIODIZED_MIXED_JET_SINGLE_TRANSLATE_OR_ZERO=KERNEL_TARGET
echo CLAUSE09_TRANSFER=NEXT_FRONTIER
echo MIXED_JET_TRANSLATION_LAW=EXACT_REMAINING_BRIDGE
echo CLAUSE09_PERIODIZATION_TRANSFER=KERNEL_TARGET
echo PERIODIZED_FORCE_OFFICIAL_ADMISSIBLE=KERNEL_TARGET
echo COROLLARY106_FINAL_FORCE_CLAUSE09=KERNEL_TARGET
echo COROLLARY106_FINAL_FORCE_ADMISSIBLE=KERNEL_TARGET
echo TRANSLATION_LAW_PROOF=NEXT_FRONTIER
echo RESCALED_SOURCE_REALIZATION=NEXT_FRONTIER
echo VECTOR_DX_TRANSLATION_COMMUTES=KERNEL_TARGET
echo REPEATED_VECTOR_DX_TRANSLATION_COMMUTES=KERNEL_TARGET
echo SPATIAL_JET_TRANSLATION_COMMUTES=KERNEL_TARGET
echo VECTOR_DT_TRANSLATION_COMMUTES=DEFINITIONAL
echo REPEATED_VECTOR_DT_TRANSLATION_COMMUTES=KERNEL_TARGET
echo MIXED_JET_TRANSLATION_LAW=KERNEL_PROVED_UNCONDITIONAL
echo CLAUSE09_TRANSLATION_HYPOTHESIS=ELIMINATED
echo PERIODIZED_FORCE_ADMISSIBILITY_TRANSLATION_CLOSED=KERNEL_TARGET
echo COROLLARY106_FORCE_ADMISSIBILITY_TRANSLATION_CLOSED=KERNEL_TARGET
echo RESCALED_SOURCE_SUPPORT_SMOOTHNESS_CLAUSE09=NEXT_FRONTIER
echo RUN=PASS

