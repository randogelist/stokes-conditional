FEF_NSE_CONCRETE_SOURCE_RESCALING_LEAN_v0_20_27

Builds on the PASS of v0.20.26.

This package deliberately advances several generations before stopping.

GENERATION 1
============
Prove exact spatial support transport under parabolic scaling:

  SpatialCubeSupported R f
  0 < lam
  --------------------------------
  SpatialCubeSupported (R / lam) (rescaleForce lam t0 f)

GENERATION 2
============
Prove the affine parabolic space-time map is C-infinity and therefore

  GloballySmoothForce f
  --------------------------------
  GloballySmoothForce (rescaleForce lam t0 f)

GENERATION 3
============
Use the two preceding results to eliminate rescaled support and rescaled
smoothness from the final official periodic-force admissibility theorem:

  source support
  source global smoothness
  source radius / lam < sigma
  2*sigma < 1
  clause09 of the rescaled source
  --------------------------------
  admissibleForce realAnalysis Domain.periodic
    (corollary106PeriodicForce lam t0 f)

Thus after this package, if it passes, the only remaining force-side analytic
port in that theorem is `clause09` for the rescaled source.

GENERATION 4
============
Prove a concrete nonzero source value survives literal Z^3 periodization.
This is a later bridge to the nonzero Case-III classification.

Also introduces `Corollary106SourceForceReady`, a compact source-side interface
whose `admissible` theorem produces the official periodic admissible force.

No PDE blowup/no-global statement is claimed here.

Run:
cd /d "%USERPROFILE%\Downloads" && tar.exe -xf "FEF_NSE_CONCRETE_SOURCE_RESCALING_LEAN_v0_20_27.zip" && call "FEF_NSE_CONCRETE_SOURCE_RESCALING_LEAN_v0_20_27\run.cmd"
