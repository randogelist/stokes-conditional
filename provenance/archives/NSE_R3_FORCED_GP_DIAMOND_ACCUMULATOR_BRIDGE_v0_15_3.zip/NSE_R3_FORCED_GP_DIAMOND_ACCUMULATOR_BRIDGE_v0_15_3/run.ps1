$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root
# Keep the native Win32 current directory aligned with PowerShell's provider location.
[System.Environment]::CurrentDirectory = $root

function Find-RocqBin {
  if ($env:ROCQBIN) {
    $r = Join-Path $env:ROCQBIN 'rocq.exe'
    $c = Join-Path $env:ROCQBIN 'rocqchk.exe'
    if ((Test-Path -LiteralPath $r) -and (Test-Path -LiteralPath $c)) { return $env:ROCQBIN }
  }
  $preferred = 'C:\Rocq-Platform~9.1~2026.01\bin'
  if ((Test-Path -LiteralPath (Join-Path $preferred 'rocq.exe')) -and
      (Test-Path -LiteralPath (Join-Path $preferred 'rocqchk.exe'))) { return $preferred }
  $cmd = Get-Command rocq.exe -ErrorAction SilentlyContinue
  if ($cmd) {
    $b = Split-Path -Parent $cmd.Source
    if (Test-Path -LiteralPath (Join-Path $b 'rocqchk.exe')) { return $b }
  }
  $roots = @('C:\Rocq-Platform~9.1~2026.01','C:\Rocq-Platform~9.1','C:\Program Files\Rocq Platform')
  foreach($base in $roots) {
    if (Test-Path -LiteralPath $base) {
      $hit = Get-ChildItem -LiteralPath $base -Filter rocq.exe -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($hit) {
        $b = Split-Path -Parent $hit.FullName
        if (Test-Path -LiteralPath (Join-Path $b 'rocqchk.exe')) { return $b }
      }
    }
  }
  throw 'rocq.exe/rocqchk.exe not found. Set ROCQBIN to the Rocq 9.1 bin directory.'
}

$bin  = Find-RocqBin
$rocq = Join-Path $bin 'rocq.exe'
$chk  = Join-Path $bin 'rocqchk.exe'

# Native Windows Rocq/OCaml subprocesses may need MinGW runtime DLLs
# (notably libgmp-10.dll) on PATH even when rocq.exe --version itself works.
$platformRoot = Split-Path -Parent $bin
$dllDirs = New-Object System.Collections.Generic.List[string]
$dllDirs.Add($bin)
foreach($dllName in @('libgmp-10.dll','libgcc_s_seh-1.dll','libwinpthread-1.dll','libstdc++-6.dll')) {
  $hit = Get-ChildItem -LiteralPath $platformRoot -Filter $dllName -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($hit) {
    $d = $hit.Directory.FullName
    if (-not $dllDirs.Contains($d)) { $dllDirs.Add($d) }
    Write-Host "DLL_$dllName=$($hit.FullName)"
  }
}
$oldPathParts = @($env:PATH -split ';' | Where-Object { $_ })
$newPathParts = @($dllDirs) + $oldPathParts
$env:PATH = (($newPathParts | Select-Object -Unique) -join ';')
$env:ROCQBIN = $bin
Write-Host "ROCQ_PATH_PREFIX=$($dllDirs -join ';')"
Write-Host "ROOT=$root"
Write-Host "NATIVE_CWD=$([System.Environment]::CurrentDirectory)"
Write-Host "ROCQ=$rocq"
& $rocq --version
if ($LASTEXITCODE -ne 0) { throw "rocq --version failed: $LASTEXITCODE" }

$buildOrder = Join-Path $root 'build_order.txt'
$files = @(Get-Content -LiteralPath $buildOrder | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') })
Get-ChildItem -LiteralPath $root -File -ErrorAction SilentlyContinue |
  Where-Object { $_.Extension -in @('.vo','.vos','.vok','.glob') } |
  Remove-Item -Force -ErrorAction SilentlyContinue

$i = 0
foreach($f in $files) {
  $i++
  $full = Join-Path $root $f
  if (-not (Test-Path -LiteralPath $full)) { throw "COMPILE_FILE=$f MISSING path=$full" }
  Write-Host "[$i/$($files.Count)] COMPILE $f"
  # IMPORTANT: absolute source path, so rocq never depends on the caller's CWD.
  & $rocq compile -q $full
  if ($LASTEXITCODE -ne 0) { throw "COMPILE_FILE=$f FAIL exit=$LASTEXITCODE" }
  Write-Host "COMPILE_FILE=$f PASS"
}
Write-Host 'COMPILE=PASS'

Write-Host '[ROCQCHK]'
# rocqchk resolves sibling .vo dependencies from the package root; both PS and Win32 CWD are pinned above.
$mods = @(
  'awpi_nse_gp_perspective_action_v0_11_2',
  'awpi_nse_gp_closed_action_envelope_v0_19_2',
  'awpi_nse_gp_finite_cutoff_envelope_v0_20_0',
  'awpi_nse_gp_restart_action_covariance_v0_14_2',
  'awpi_nse_gp_matched_heat_renewal_v0_6_0',
  'awpi_nse_gp_compact_triad_projection_v0_7_1',
  'awpi_nse_gp_quarter_shift_firewall_v0_13_6',
  'awpi_nse_gp_to_m7_spine_v0_21_7',
  'awpi_nse_m7_critical_energy_injection_v0_35_8',
  'awpi_nse_gp_leray_modal_triad_adapter_v0_13_3',
  'awpi_nse_gp_source_class_ownership_v0_25_4',
  'awpi_nse_gp_parent_degree_reproduction_v0_26_0',
  'awpi_nse_gp_renewal_reduction_v0_3_1',
  'awpi_nse_gp_to_m7_route_v0_28_3',
  'awpi_nse_gp_gk_cohomology_realization_v0_35_3',
  'NSE_R3_F0_GP_DIAMOND',
  'awpi_nse_gp_three_leg_route_realization_v0_36_4',
  'NSE_R3_F0_GP_DIAMOND_ROUTE',
  'awpi_nse_gp_complex_helical_adapter_v0_14_1',
  'awpi_nse_gp_ae_modal_semantics_v0_23_1',
  'awpi_nse_gp_complex_three_leg_realization_v0_37_4',
  'awpi_nse_gp_complex_source_envelope_realization_v0_38_0',
  'awpi_nse_leray_ae_to_parent_route_v0_39_0',
  'awpi_nse_leray_projected_modes_v0_40_0',
  'awpi_nse_leray_dual_evolution_v0_41_5',
  'awpi_nse_leray_weak_test_specialization_v0_42_1',
  'NSE_R3_F0_GP_DIAMOND_LH_ROUTE',
  'NSE_R3_F0_GP_DIAMOND_AE_ENTRANCE',
  'NSE_R3_F0_GP_DIAMOND_DISTRIBUTION_BRIDGE',
  'NSE_R3_F0_GP_DIAMOND_GENERATION_ASSEMBLY',
  'NSE_R3_F0_GP_DIAMOND_CANONICAL_LEDGER',
  'NSE_R3_F0_GP_DIAMOND_CHILD_CONTINUATION',
  'NSE_R3_FORCED_GP_DIAMOND_CRITICAL_CLASSES',
  'NSE_R3_FORCED_GP_DIAMOND_SEPARATRIX',
  'NSE_R3_FORCED_GP_DIAMOND_FORCE_ENVELOPE',
  'NSE_R3_FORCED_GP_DIAMOND_STOKES_DUALITY',
  'NSE_R3_FORCED_GP_DIAMOND_INTRINSIC_FORCE_CLASS',
  'NSE_R3_FORCED_GP_DIAMOND_FORCE_ABSORPTION',
  'NSE_R3_FORCED_GP_DIAMOND_ACCUMULATOR_BRIDGE'
)
& $chk -silent @mods
if ($LASTEXITCODE -ne 0) { throw "ROCQCHK=FAIL exit=$LASTEXITCODE" }
Write-Host 'ROCQCHK=PASS'

$bad = Select-String -Path (Join-Path $root '*.v') -Pattern '\b(Admitted|admit|Axiom|Parameter|Abort)\b' -AllMatches -ErrorAction SilentlyContinue
if ($bad) {
  $bad | ForEach-Object { Write-Host $_ }
  throw 'PROOF_ESCAPE_SCAN=FAIL'
}
Write-Host 'PROOF_ESCAPE_SCAN=PASS'
Write-Host 'STATUS=NSE_R3_FORCED_GP_DIAMOND_CRITICAL_CLASSES_V0_9_0'
Write-Host 'BASE_CHILD_CONTINUATION_V0_8_2=IMPORTED_KERNEL_TARGET'
Write-Host 'FORCED_BALANCE_TO_EXISTING_CRITICAL_BALANCE=KERNEL_TARGET'
Write-Host 'BOUNDED_INTERNAL_PLUS_EXTERNAL_LEDGER_TO_REGULARITY=KERNEL_TARGET'
Write-Host 'ZERO_FORCE_RECOVERS_UNFORCED_LEDGER=KERNEL_TARGET'
Write-Host 'UNBOUNDED_EXACT_NET_WORK_TO_CRITICAL_MASS_UNBOUNDED=KERNEL_TARGET'
Write-Host 'BREAKDOWN_CLASS_EXCLUDES_CRITICAL_BOUNDEDNESS=KERNEL_TARGET'
Write-Host 'BREAKDOWN_CLASS_EXCLUDES_PHYSICAL_REGULARITY=KERNEL_TARGET_WITH_EXPLICIT_REGULARITY_READOUT'
Write-Host 'L2T_HM12_MAXIMAL_UNIFORM_FORCE_CLASS=OPEN_STANDARD_FUNCTIONAL_ANALYTIC_INTERFACE'
Write-Host 'BKQR_FORCE_LEDGER_IDENTIFICATION=OPEN_RESEARCH_INTERFACE'
Write-Host 'STATUS=NSE_R3_FORCED_GP_DIAMOND_SEPARATRIX_V0_10_0'
Write-Host 'BASE_FORCED_CRITICAL_CLASSES_V0_9_0=IMPORTED_KERNEL_TARGET'
Write-Host 'BOUNDED_MASS_TRAPS_CUMULATIVE_DEFECT=KERNEL_TARGET'
Write-Host 'QUANTITATIVE_SEPARATRIX_BAND=KERNEL_TARGET'
Write-Host 'FIXED_SUBCRITICAL_GAP_BOUNDS_TURNOVER=KERNEL_TARGET'
Write-Host 'FIXED_SUPERCRITICAL_GAP_FORCES_MASS_GROWTH=KERNEL_TARGET'
Write-Host 'SUPERCRITICAL_UNBOUNDED_TURNOVER_TO_BREAKDOWN=KERNEL_TARGET'
Write-Host 'BOUNDED_HIGH_TURNOVER_FORCES_SEPARATRIX=KERNEL_TARGET'
Write-Host 'L2T_HM12_MAXIMAL_UNIFORM_FORCE_CLASS=OPEN_STANDARD_FUNCTIONAL_ANALYTIC_INTERFACE'
Write-Host 'BKQR_FORCE_LEDGER_IDENTIFICATION=OPEN_RESEARCH_INTERFACE'
Write-Host 'STATUS=NSE_R3_FORCED_GP_DIAMOND_FORCE_ENVELOPE_V0_11_1'
Write-Host 'BASE_FORCED_SEPARATRIX_V0_10_0=IMPORTED_KERNEL_TARGET'
Write-Host 'CRITICAL_DUAL_SIZE_IS_LEAST_UNIFORM_WORK_COEFFICIENT=KERNEL_TARGET'
Write-Host 'CHANNEL_DUAL_SIZE_IS_LEAST_UNIFORM_WORK_COEFFICIENT=KERNEL_TARGET'
Write-Host 'UNIVERSAL_BKQR_FORCE_ENVELOPE_EQUALS_GLOBAL_CRITICAL_SIZE=KERNEL_TARGET'
Write-Host 'TRAJECTORY_BKQR_FORCE_ACTION_LE_UNIVERSAL_ENVELOPE=KERNEL_TARGET'
Write-Host 'BOUNDED_FORCE_ENVELOPE_TO_BOUNDED_PHYSICAL_LEDGER=KERNEL_TARGET'
Write-Host 'STOKES_CRITICAL_DUAL_SIZE_EQ_HMINUSHALF=OPEN_STANDARD_FUNCTIONAL_ANALYTIC_INTERFACE'
Write-Host 'TIME_ACCUMULATED_FORCE_SIZE_EQ_L2T_HMINUSHALF=OPEN_STANDARD_FUNCTIONAL_ANALYTIC_INTERFACE'
Write-Host 'BKQR_TIGHT_FORCE_FRAME_REALIZATION=OPEN_RESEARCH_INTERFACE'
Write-Host 'STATUS=NSE_R3_FORCED_GP_DIAMOND_STOKES_DUALITY_V0_12_2'
Write-Host 'BASE_FORCE_ENVELOPE_V0_11_1=IMPORTED_KERNEL_TARGET'
Write-Host 'FRACTIONAL_STOKES_TO_CRITICAL_DUAL_GEOMETRY=KERNEL_TARGET'
Write-Host 'STOKES_HMINUSHALF_IS_LEAST_UNIFORM_FORCE_COEFFICIENT=KERNEL_TARGET'
Write-Host 'POINTWISE_HMINUSHALF_TO_TIME_ACCUMULATION=KERNEL_TARGET'
Write-Host 'TIME_ACCUMULATED_FORCE_SIZE_EQ_L2T_HMINUSHALF=DERIVED_FROM_POINTWISE_IDENTIFICATION'
Write-Host 'R3_STOKES_FRACTIONAL_SOBOLEV_IDENTIFICATION=OPEN_STANDARD_FUNCTIONAL_ANALYTIC_INTERFACE'
Write-Host 'BKQR_TIGHT_FORCE_FRAME_REALIZATION=OPEN_RESEARCH_INTERFACE'
Write-Host 'STATUS=NSE_R3_FORCED_GP_DIAMOND_INTRINSIC_FORCE_CLASS_V0_13_1'
Write-Host 'BASE_STOKES_DUALITY_V0_12_2=IMPORTED_KERNEL_TARGET'
Write-Host 'GLOBAL_STOKES_FORCE_ABSORPTION=KERNEL_TARGET'
Write-Host 'INTRINSIC_STOKES_FORCE_SIZE_IS_LEAST_UNIFORM_COEFFICIENT=KERNEL_TARGET'
Write-Host 'INTRINSIC_FORCE_CLASS_PLUS_INTERNAL_M7_TO_REGULARITY=KERNEL_TARGET'
Write-Host 'BKQR_FORCE_FRAME_REQUIRED_FOR_REGULARITY=NO'
Write-Host 'BKQR_FORCE_FRAME_ROLE=OPTIONAL_CHANNEL_READOUT_ONLY'
Write-Host 'R3_HMINUSHALF_IDENTIFICATION=OPTIONAL_CLASSICAL_READOUT_NOT_PROOF_INTERFACE'
Write-Host 'FORCED_ENERGY_BALANCE_WITH_INTRINSIC_STOKES_LEDGER=OPEN_STANDARD_ANALYTIC_INTERFACE'
Write-Host 'STATUS=NSE_R3_FORCED_GP_DIAMOND_FORCE_ABSORPTION_V0_14_0'
Write-Host 'BASE_INTRINSIC_FORCE_CLASS_V0_13_1=IMPORTED_KERNEL_TARGET'
Write-Host 'FORCE_SPENDS_ONLY_THETA_FRACTION_OF_EFFECTIVE_VISCOSITY=KERNEL_TARGET'
Write-Host 'RESIDUAL_VISCOSITY_EQUALS_ONE_MINUS_THETA_TIMES_UNFORCED_EFFECTIVE_VISCOSITY=KERNEL_TARGET'
Write-Host 'POST_M7_PLUS_INTRINSIC_FORCE_ABSORPTION_TO_FORCED_BALANCE=KERNEL_TARGET'
Write-Host 'BOUNDED_INTRINSIC_FORCE_SIZE_TO_BOUNDED_NORMALIZED_LEDGER=KERNEL_TARGET'
Write-Host 'POST_M7_INTRINSIC_FORCE_CLASS_TO_REGULARITY=KERNEL_TARGET'
Write-Host 'FORCED_NSE_TO_POST_M7_CRITICAL_BALANCE=OPEN_STANDARD_ANALYTIC_INTERFACE'
Write-Host 'POINTWISE_STOKES_YOUNG_TO_ACCUMULATED_ABSORPTION=OPEN_STANDARD_ANALYTIC_INTERFACE'
Write-Host 'STATUS=NSE_R3_FORCED_GP_DIAMOND_ACCUMULATOR_BRIDGE_V0_15_3'
Write-Host 'BASE_FORCE_ABSORPTION_V0_14_0=IMPORTED_KERNEL_TARGET'
Write-Host 'POSITIVE_LINEAR_ACCUMULATOR_TO_ABSORPTION=KERNEL_TARGET'
Write-Host 'STOKES_POINTWISE_NORMALIZED_ABSORPTION=KERNEL_TARGET'
Write-Host 'POINTWISE_STOKES_YOUNG_TO_ACCUMULATED_ABSORPTION=KERNEL_TARGET'
Write-Host 'POINTWISE_STOKES_YOUNG_TO_ACCUMULATED_ABSORPTION_INTERFACE=ELIMINATED'
Write-Host 'FORCED_NSE_TO_POST_M7_CRITICAL_BALANCE=OPEN_STANDARD_ANALYTIC_INTERFACE'
Write-Host 'RUN=PASS'
