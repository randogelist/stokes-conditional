NSE_R3_FORCED_GP_DIAMOND_SEPARATRIX_v0_10_0

Adds a quantitative scalar separatrix theorem on top of the passing forced critical-classes baseline.

Key point:
  critical_mass = initial_mass + 2*(positive_work-loss_work).

Consequences formalized:
- bounded critical mass traps the cumulative signed defect;
- sufficiently large turnover with bounded mass forces an arbitrarily thin relative balance band;
- a fixed subcritical gap cannot coexist with unbounded turnover;
- a fixed supercritical gap plus unbounded turnover forces critical-mass breakdown;
- bounded high-turnover trajectories cannot stay uniformly on either side of the separatrix.
