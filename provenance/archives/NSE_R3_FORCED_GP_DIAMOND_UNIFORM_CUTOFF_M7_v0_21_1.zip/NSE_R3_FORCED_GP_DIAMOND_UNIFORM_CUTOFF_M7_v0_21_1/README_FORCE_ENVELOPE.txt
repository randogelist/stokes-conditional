NSE_R3_FORCED_GP_DIAMOND_FORCE_ENVELOPE_v0_11_1

Purpose:
- formalize the exact critical dual coefficient as the least uniform work coefficient;
- formalize a finite tight BKQR force frame;
- prove that the sum of channel least coefficients equals the global critical dual size;
- prove every trajectory-dependent quadratic BKQR force action is bounded by that universal envelope;
- transfer boundedness of the cumulative force envelope to the physical external ledger.

Claim boundary:
- the algebraic Hilbert/Riesz consequences are proved in this root;
- identifying the global critical dual size with the Stokes H^{-1/2} norm remains standard functional analysis;
- identifying the cumulative size with the L^2_t H^{-1/2} norm remains standard time-integration analysis;
- realizing the actual BKQR cuts as a tight force frame remains the project-specific research interface.
