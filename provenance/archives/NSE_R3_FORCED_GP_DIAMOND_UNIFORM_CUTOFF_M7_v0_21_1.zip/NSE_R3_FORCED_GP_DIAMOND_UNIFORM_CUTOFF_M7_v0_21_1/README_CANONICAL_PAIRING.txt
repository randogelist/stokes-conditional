NSE R3 forced GP Diamond canonical pairing v0.18.0

Purpose:
- define the mass derivative, dissipation and force current canonically from the critical test pairing;
- derive ForcedNSECriticalPairingData from only the forced critical operator identity plus the nonlinear safe/resistant split;
- define critical_mass canonically as initial mass plus accumulated mass derivative, eliminating the separate primitive theorem;
- compose directly with the passing pointwise M7 bridge to obtain the post-M7 forced critical balance.

Claim boundary:
- FORCED_CRITICAL_OPERATOR_PAIRING: standard analytic critical-test identity for the actual forced NSE trajectory;
- CANONICAL_CRITICAL_MASS_NONNEG_READOUT: standard physical identification/nonnegativity of the canonical critical mass;
- POINTWISE_M7_SAFE_RESISTANT_SPLIT_REALIZATION: project-specific M7 realization and nonlinear split.
