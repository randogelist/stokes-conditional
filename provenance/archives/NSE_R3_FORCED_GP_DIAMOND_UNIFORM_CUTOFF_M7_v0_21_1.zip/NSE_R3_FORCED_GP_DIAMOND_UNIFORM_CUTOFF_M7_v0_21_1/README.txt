NSE_R3_F0_GP_DIAMOND_CANONICAL_LEDGER_v0_7_1

Purpose:
Contract the inter-generation M7 ledger for the unforced R^3 GP Diamond.

Kernel targets in this layer:
- define generation action canonically as the selected route forest's parent action;
- derive nonnegativity of the canonical generation action;
- eliminate CURRENT_PARENT_COVERAGE by definitional equality;
- define the canonical legal-cost sequence as the selected forest legal cost;
- construct canonical zero GK certificates for the scale and future channels;
- reduce the former three payment channels to one GK certificate for the actual legal-cost sequence;
- prove that canonical next-generation ownership plus that single legal-cost GK certificate yields ActualDiscreteGPM7.

Open standard analytic interfaces inherited from v0.6.3:
- ZERO_DISTRIBUTION_AE_FAITHFULNESS
- LH_WEAK_TERM_DISTRIBUTION_REPRESENTATION
- CONULL_NONEMPTY

Open research interfaces after this contraction:
- LH_FINITE_GENERATION_SLOT_PACKAGING
- CANONICAL_NEXT_GENERATION_OWNERSHIP
- CANONICAL_LEGAL_COST_GK
- CRITICAL_TIME_ROUTE_DEPTH

v0.8.0 child-source continuation contraction:
The old scalar CANONICAL_NEXT_GENERATION_OWNERSHIP frontier is derived from a richer physical source-class continuation statement using the actual k/p/q child classes retained by ComplexThreeLegPhysicalCertificate.
