NSE_R3_FORCED_GP_DIAMOND_FORCE_ABSORPTION_v0_14_0

Purpose:
  Convert the post-M7 forced critical balance into the existing forced-Diamond
  balance using only a theta-fraction of the remaining effective viscosity.

Kernel targets in the new root:
  * forced sigma stays in [0,1)
  * residual viscosity identity:
      e_forced = (1-theta) e_unforced
  * post-M7 balance + accumulated intrinsic Stokes absorption -> forced balance
  * bounded intrinsic force size -> bounded normalized force ledger
  * bounded internal M7 ledger + bounded intrinsic force size -> critical regularity

Open standard analytic interfaces:
  * actual forced NSE -> post-M7 critical balance before external-force absorption
  * integrate the pointwise Stokes/Young force estimate into accumulated absorption
