NSE_R3_FORCED_GP_DIAMOND_CRITICAL_BALANCE_BRIDGE_v0_16_0

Purpose:
Reduce the last forced A-side entrance FORCED_NSE_TO_POST_M7_CRITICAL_BALANCE
into the standard raw forced critical-energy inequality plus the already-used
M7 safe/resistant local geometry.

Kernel targets in this layer:
- raw forced critical balance + accumulated internal M7 absorption -> PostM7ForcedCriticalBalance;
- quadratic resistant action r^2 <= a d -> normalized absorption 2r <= e d + a/e;
- positive linear accumulation transports the pointwise safe/resistant inequalities;
- one-shot composition from raw forced critical balance + pointwise M7 data to the post-M7 balance consumed by v0.14/v0.15.

Remaining interfaces after this contraction:
- FORCED_NSE_RAW_CRITICAL_IDENTITY: standard forced H^(1/2) critical energy inequality;
- POINTWISE_M7_SAFE_RESISTANT_REALIZATION: identify the actual NSE nonlinear decomposition with the safe/resistant quantities already used by the M7 critical-energy algebra.
