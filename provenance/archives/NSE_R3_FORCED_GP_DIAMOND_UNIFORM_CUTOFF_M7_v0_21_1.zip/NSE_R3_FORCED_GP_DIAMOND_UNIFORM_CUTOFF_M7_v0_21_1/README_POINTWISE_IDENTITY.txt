NSE R3 forced GP Diamond pointwise identity v0.17.1

Contraction:
  forced NSE critical pairing identity
  + critical-mass primitive / fundamental theorem
  + positive linear accumulator
  -> raw forced critical balance
  -> existing v0.16.1 M7 internal absorption
  -> post-M7 forced critical balance.

Open interfaces after this contraction:
  FORCED_NSE_CRITICAL_PAIRING_REALIZATION (standard analytic/operator interface)
  CRITICAL_MASS_PRIMITIVE_FUNDAMENTAL_THEOREM (standard analytic interface)
  POINTWISE_M7_SAFE_RESISTANT_REALIZATION (research interface)
