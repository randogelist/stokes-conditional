NSE R3 forced GP Diamond intrinsic force class v0.13.0

Purpose:
- remove BKQR tight-force-frame realization from the regularity A-side;
- absorb external forcing directly through the global Stokes critical-dual geometry;
- define the maximal uniform forcing class intrinsically by A^{-1/4}, with classical H^{-1/2} only an optional R3 readout.

Claim boundary:
- internal nonlinear transfer still uses the existing GP/BKQR/M7 chain;
- external forcing regularity uses only the intrinsic Stokes force ledger;
- deriving the integrated forced energy balance from the actual PDE and time integration remains a standard analytic interface;
- identifying the intrinsic R3 class with classical homogeneous H^{-1/2} is optional nomenclature/readout, not needed for the proof.
