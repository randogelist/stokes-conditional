NSE R3 forced GP Diamond operator-test contraction v0.19.1

Purpose:
- derive the scalar forced critical pairing from the actual vector/operator NSE equality by bilinearity;
- derive nonnegativity of the canonical critical mass from a physical norm-square readout plus the standard critical-space chain rule;
- compose both with the passing canonical-pairing + M7 theorem.

Remaining interfaces:
1. actual forced NSE operator equality in the critical dual/test space (standard analytic entrance),
2. critical norm-square chain rule/fundamental theorem (standard analytic entrance),
3. pointwise M7 safe/resistant split realization (research interface).
