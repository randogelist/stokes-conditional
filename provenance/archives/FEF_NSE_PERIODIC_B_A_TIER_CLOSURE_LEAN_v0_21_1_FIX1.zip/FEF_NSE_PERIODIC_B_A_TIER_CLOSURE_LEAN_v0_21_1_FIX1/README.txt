FEF_NSE_PERIODIC_B_A_TIER_CLOSURE_LEAN_v0_21_1_FIX1

FIX1
----
v0.21.0 already compiled the substantive non-PDE B layer cleanly:

  zeroRForce_globallySmooth
  zeroRForce_clause09
  projectZeroForce_admissible_periodic
  periodicBPhysicalPort_iff_endpoint

all without sorryAx.

The only failures were the final equivalence wrappers.

Reason:
  B unfolds to:
    statement realAnalysis Case.B

The original simp set included:
  B, statementAt

but omitted the intermediate definition:
  statement

and the final semantic definition:
  unforcedGlobalAt

Fix:
Both directions now use:

  simpa [PeriodicZeroForceGlobalRegularity,
    B, statement, statementAt, unforcedGlobalAt] using h

No theorem statement, endpoint, analytic hypothesis, or runner architecture
changes.

Run:
cd /d "%USERPROFILE%\Downloads" && tar.exe -xf "FEF_NSE_PERIODIC_B_A_TIER_CLOSURE_LEAN_v0_21_1_FIX1.zip" && call "FEF_NSE_PERIODIC_B_A_TIER_CLOSURE_LEAN_v0_21_1_FIX1\run.cmd"
