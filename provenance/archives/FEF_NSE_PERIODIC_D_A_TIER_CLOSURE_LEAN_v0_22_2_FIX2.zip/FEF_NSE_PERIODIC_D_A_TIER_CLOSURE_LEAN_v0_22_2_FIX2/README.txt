FEF_NSE_PERIODIC_D_A_TIER_CLOSURE_LEAN_v0_22_2_FIX2

FIX2
----
v0.22.1 confirmed that the core D closure is already clean:

  periodicForcedBreakdownAt_iff_breakdownAt
  PERIODIC_FORCED_BREAKDOWN_IFF_D
  PERIODIC_D_PHYSICAL_PORT_IFF_D
  periodicZeroInitialForcedBreakdown_implies_D

all compile without sorryAx.

The only failure is the optional Corollary-10.6 semantic witness package.

Cause:
It was declared:

  structure PeriodicCorollary106SemanticPort : Prop where
    force : forall nu, Force realAnalysis
    ...

Lean does not permit a Prop-valued structure to project computational data.
A proof-irrelevant `Prop` structure may only have proof fields; `force` is
data.

Correct fix:
  structure PeriodicCorollary106SemanticPort : Type where

This is semantically appropriate: the port is a witness package carrying an
actual viscosity-indexed force family together with its admissibility and
no-global proofs.

No D endpoint, theorem statement, force construction, or analytic hypothesis
changes.

Run:
cd /d "%USERPROFILE%\Downloads" && tar.exe -xf "FEF_NSE_PERIODIC_D_A_TIER_CLOSURE_LEAN_v0_22_2_FIX2.zip" && call "FEF_NSE_PERIODIC_D_A_TIER_CLOSURE_LEAN_v0_22_2_FIX2\run.cmd"
