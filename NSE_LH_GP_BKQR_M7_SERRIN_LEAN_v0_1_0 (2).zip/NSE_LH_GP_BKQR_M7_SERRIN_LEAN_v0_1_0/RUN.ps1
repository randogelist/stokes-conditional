$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Set-Location -LiteralPath $PSScriptRoot

function Invoke-Checked {
    param([string]$Label, [string[]]$Arguments)
    Write-Host ('CHECK=' + $Label)
    $start = New-Object System.Diagnostics.ProcessStartInfo
    $start.FileName = $script:LakeExe
    $start.WorkingDirectory = $PSScriptRoot
    $start.UseShellExecute = $false
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $start.Arguments = ($Arguments | ForEach-Object {
        if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ }
    }) -join ' '
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $start
    [void]$process.Start()
    $outTask = $process.StandardOutput.ReadToEndAsync()
    $errTask = $process.StandardError.ReadToEndAsync()
    $process.WaitForExit()
    $stdout = $outTask.Result
    $stderr = $errTask.Result
    $code = $process.ExitCode
    $process.Dispose()
    $text = $stdout + $stderr
    [IO.File]::WriteAllText((Join-Path $PSScriptRoot ('validation_logs/' + $Label + '.log')), $text)
    if ($text.Length -gt 0) { Write-Host $text }
    if ($code -ne 0) { throw ($Label + ' failed, exit ' + $code) }
    return $text
}

try {
    [void](New-Item -ItemType Directory -Force -Path 'validation_logs')
    $manifest = Get-Content -LiteralPath 'SHA256SUMS.txt'
    foreach ($line in $manifest) {
        if ($line.Trim().Length -eq 0) { continue }
        if ($line -notmatch '^([a-f0-9]{64})  (.+)$') { throw 'Invalid source hash manifest' }
        $expected = $Matches[1]
        $relative = $Matches[2]
        $actual = (Get-FileHash -LiteralPath $relative -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $expected) { throw ('Hash mismatch: ' + $relative) }
    }
    $leanFiles = @(Get-ChildItem -LiteralPath 'NSE' -Filter '*.lean' -File -Recurse)
    $expectedModules = @(Get-Content -LiteralPath 'MODULES.txt' | Where-Object { $_.Trim().Length -gt 0 })
    if ($leanFiles.Count -ne $expectedModules.Count) { throw 'Custom module count mismatch' }
    foreach ($module in $expectedModules) {
        if (-not (Test-Path -LiteralPath (($module -replace '\.', '/') + '.lean'))) {
            throw ('Missing custom module: ' + $module)
        }
    }
    $forbidden = '(?m)^\s*(axiom|unsafe|partial|opaque)\b|\b(sorry|admit|native_decide|ofReduceBool|implemented_by|extern)\b|debug\.skipKernelTC'
    foreach ($source in $leanFiles) {
        if ([IO.File]::ReadAllText($source.FullName) -match $forbidden) {
            throw ('Forbidden proof construct: ' + $source.Name)
        }
    }
    if ((Get-Content -Raw -LiteralPath 'lean-toolchain').Trim() -ne 'leanprover/lean4:v4.33.0') {
        throw 'Unexpected Lean toolchain'
    }
    $lakeManifest = Get-Content -Raw -LiteralPath 'lake-manifest.json' | ConvertFrom-Json
    $mathlib = @($lakeManifest.packages | Where-Object { $_.name -eq 'mathlib' })
    if ($mathlib.Count -ne 1 -or $mathlib[0].rev -ne 'db584cd6d46c92f209a44c0f1c829460d327499d') {
        throw 'Unexpected mathlib revision'
    }
    Write-Host 'SOURCE_AUDIT=PASS'
    $lakeCommand = Get-Command 'lake' -ErrorAction SilentlyContinue
    if ($null -eq $lakeCommand) {
        $elanLake = Join-Path $env:USERPROFILE '.elan/bin/lake.exe'
        if (-not (Test-Path -LiteralPath $elanLake)) {
            throw 'Lake not found. Install Lean/elan and Git, then run RUN.cmd again.'
        }
        $script:LakeExe = $elanLake
        $env:PATH = (Split-Path -Parent $elanLake) + ';' + $env:PATH
    } else { $script:LakeExe = $lakeCommand.Source }
    if (-not $env:LEAN_NUM_THREADS) { $env:LEAN_NUM_THREADS = '16' }
    $version = Invoke-Checked -Label 'VERSION' -Arguments @('env', 'lean', '--version')
    if ($version -notmatch 'version 4\.33\.0[,)]') { throw 'Compiler is not Lean 4.33.0' }
    [void](Invoke-Checked -Label 'CACHE' -Arguments @('exe', 'cache', 'get'))
    # Re-elaborate every custom source on this machine. Dependency caches are retained.
    foreach ($suffix in @('lib/lean/NSE', 'ir/NSE')) {
        $customBuild = Join-Path '.lake/build' $suffix
        if (Test-Path -LiteralPath $customBuild) { Remove-Item -LiteralPath $customBuild -Recurse -Force }
    }
    [void](Invoke-Checked -Label 'BUILD' -Arguments @('build'))
    $audit = Invoke-Checked -Label 'AXIOMS' -Arguments @('env', 'lean', 'NSE/Audit.lean')
    if ($audit -notmatch 'ALL_CUSTOM_AXIOMS=PASS') { throw 'Axiom audit marker missing' }
    [void](Invoke-Checked -Label 'KERNEL_CUSTOM' -Arguments @('env', 'leanchecker', 'NSE'))
    [void](Invoke-Checked -Label 'KERNEL_RECURSIVE' -Arguments @('env', 'leanchecker', '--fresh', 'NSE.Audit'))
    Get-Content -LiteralPath 'PASS_MARKERS.txt' | ForEach-Object { Write-Host $_ }
    Write-Host 'RUN=PASS'
    exit 0
} catch {
    Write-Host ('RUN=FAIL: ' + $_.Exception.Message)
    exit 1
}
