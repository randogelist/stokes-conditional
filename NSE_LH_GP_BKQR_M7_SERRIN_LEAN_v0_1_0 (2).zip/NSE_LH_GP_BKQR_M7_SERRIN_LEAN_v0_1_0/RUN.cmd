@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN.ps1"
exit /b %ERRORLEVEL%
